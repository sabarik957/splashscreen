package com.scriptzone.flashscreen;

import android.content.SharedPreferences;

public class Appconfig {
    public static String Appname = "com.scriptzone.flashscreen";
    public static String PlaystoreVersion="PlaystoreVersion";



}
