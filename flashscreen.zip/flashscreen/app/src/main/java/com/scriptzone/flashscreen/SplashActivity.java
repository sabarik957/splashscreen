package com.scriptzone.flashscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static com.scriptzone.flashscreen.Appconfig.Appname;

public class SplashActivity<SplashScreenActivity> extends AppCompatActivity {

    SharedPreferences prefer;

    private static int SPLASH_SCREEN_TIME_OUT = 2000;
    public static final int MULTIPLE_PERMISSIONS = 10; // code you want.

    String[] permissions = new String[]{

            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        prefer = getSharedPreferences(Appname, MODE_PRIVATE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                if (checkPermissions());
                {
                    Checkplaystoreupdate();

                    Intent i = new Intent(getApplicationContext(), NextActivity.class);
                    startActivity(i);
                }

            }
        }, SPLASH_SCREEN_TIME_OUT);
    }


    private boolean checkPermissions() {
        int result;
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : permissions) {
            result = ContextCompat.checkSelfPermission(SplashActivity.this, p);
            if (result != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p);
            }
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissionsList[], int[] grantResults) {
        switch (requestCode) {
            case MULTIPLE_PERMISSIONS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permissions granted.
                    System.out.println("Granted");
                    Log.e("permission", "Granted");
                    Checkplaystoreupdate();
                } else {
                    // no permissions granted.
                    System.out.print("Permission denied");
                   // finishAffinity();
                    //             Log.e("permission","Permission denied"+grantResults[0]);
                }
            }
        }
    }

    private void Checkplaystoreupdate() {
        String ExistingVersionName = "";
        String PlayStoreVersion = prefer.getString(Appconfig.PlaystoreVersion, "1.0");
        try {
            ExistingVersionName = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            //System.out.println("Existing version name = "+ExistingVersionName +"Playstore version = "+PlayStoreVersion);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            ExistingVersionName = "";
        }

        if (!ExistingVersionName.equalsIgnoreCase("") && !PlayStoreVersion.equalsIgnoreCase("")) {
            if (Double.parseDouble(PlayStoreVersion) > Double.parseDouble(ExistingVersionName)) {
               // showUpdateDialog();
                Log.e("Upate","upate application popup");
                Toast.makeText(this, "current playstore from shared val="+PlayStoreVersion, Toast.LENGTH_SHORT).show();
            } else {
                //checkloginid();
                Log.e("Upate","upate sharedpreference");
                prefer.edit().putString(Appconfig.PlaystoreVersion,"2.0").apply();
                Toast.makeText(this, "shared preference saved", Toast.LENGTH_SHORT).show();
            }
        }
    }

}

